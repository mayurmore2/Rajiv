package mydriverproject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class NewClass {

	public static void main(String[] args) throws Exception
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/Lesson%205-HTML%20Pages/PopupWin.html");
		//driver.findElement(By.id("txtUserName")).sendKeys("Kavita");
		System.out.println("The title is: "+ driver.getTitle());
		driver.findElement(By.id("txtPassword")).sendKeys("Kavita");
		String element=driver.findElement(By.id("txtPassword")).getAttribute("value");
		System.out.println("The password is: " + element);
		
//navigation part
		
		driver.navigate().to("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/PDFs/Test%20Automation%20and%20Advanced%20Selenium-CombinedBook.pdf");
		driver.navigate().refresh();
		driver.navigate().back();
		driver.navigate().forward();
		String  actualtitle=driver.getTitle();
		String exceptedtitle="MyHome";
		if(actualtitle.contentEquals(exceptedtitle))
			System.out.println("Actual match");
		else
			System.out.println("Title not matched");
		boolean b=driver.getPageSource().contains("Emaiistration");
		if(b==true)
			System.out.println("The heading is present");
		else
			System.out.println("The heading is not present");
		if(driver.getPageSource().matches("Email"))
			System.out.println("Matched");
		else
			System.out.println("Not Matched");
			
		System.out.println("The Current url is: "+ driver.getCurrentUrl());
		driver.findElement(By.name("submit")).submit();
		
		
		driver.quit();
	}
	
}
