package pomexamples.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class FirstAndLastName {
	
	WebDriver driver;
	
	By uname = By.id("txtUserName");
	By ln = By.name("txtLN");

	
	public FirstAndLastName(WebDriver driver) {
		super();
		this.driver = driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public void setUname() {
		this.uname = uname;
		driver.findElement(uname).sendKeys("Kaita");
		driver.close();
	}


	public void setLn() {
		this.ln = ln;
		driver.findElement(uname).sendKeys("Kaita");
		driver.close();
	}

}
