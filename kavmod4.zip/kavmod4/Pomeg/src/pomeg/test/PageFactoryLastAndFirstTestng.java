package pomeg.test;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pomexamples.pages.FirstAndLastName;
import pomexamples.pages.PagefactoryFirstAndLastName;

public class PageFactoryLastAndFirstTestng {

	@Test
	public void verify()
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		PagefactoryFirstAndLastName lp = PageFactory.initElements(driver, PagefactoryFirstAndLastName.class);
		lp.setUname();
		lp.setLn();
	}
	
	 @Test
	  public void check()
	  {
		 
		 WebDriver driver=new FirefoxDriver();
			driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		 PagefactoryFirstAndLastName lp =PageFactory.initElements(driver,  PagefactoryFirstAndLastName.class);
		  lp.setRadio();
	  }
	 
	 @Before
	 public void checkTitle()
	 {
		 WebDriver driver=new FirefoxDriver();
		  driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		 
	 }
}
