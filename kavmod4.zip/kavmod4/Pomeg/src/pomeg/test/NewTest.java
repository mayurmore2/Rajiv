package pomeg.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pomexamples.pages.FirstAndLastName;
import pomexamples.pages.PagefactoryFirstAndLastName;

public class NewTest {
  @Test
  public void verifyLogin() {
	  WebDriver driver = new FirefoxDriver();
	  driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
	  FirstAndLastName lp = new FirstAndLastName(driver);
	  lp.setUname();
	  lp.setLn(); 
  }
  
  @Test
	public void verify()
	{
		WebDriver driver=new FirefoxDriver();
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		PagefactoryFirstAndLastName lp = PageFactory.initElements(driver, PagefactoryFirstAndLastName.class);
		
		lp.setUname();
		lp.setLn();	
	}
  
 
}
