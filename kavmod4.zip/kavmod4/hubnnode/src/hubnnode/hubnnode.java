package hubnnode;


import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class hubnnode 
{
public static void main(String[] args) throws InterruptedException, MalformedURLException 

	{
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		//capabilities.setCapability("firefox_binary","C:/Users/npadmawa.CORP/AppData/Local/Mozilla Firefox/firefox.exe");
		capabilities.setPlatform(Platform.ANY);
				
		WebDriver driver = new RemoteWebDriver(new URL("http://10.220.56.47:6666/wd/hub"), capabilities);
try {
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		System.out.println(driver.getTitle());
//		driver.quit();
}
catch(Exception ex){
	System.out.println("Hello");
}
}
	}

