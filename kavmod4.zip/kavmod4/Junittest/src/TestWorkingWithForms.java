import static org.junit.Assert.*;

import java.util.concurrent.*;

import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class TestWorkingWithForms {

	static WebDriver driver= new FirefoxDriver();
	
	@BeforeClass
	public static void openBrowser()
	{
		driver.get("file://localhost/D:/Users/ADM-IG-HWDLAB1B/Desktop/kavita%20module%204/WorkingWithForms.html");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
	}
	
	@Test
	public void testTitle()
	{
		String title=driver.getTitle();
		System.out.println(title);
		assertEquals("Email Registration Form",title);
		
	}
	
	@Test
	public void  testAlert() throws Exception
	{
		driver.findElement(By.name("txtPwd")).sendKeys("kavi");
		Thread.sleep(2000);
		System.out.println("The password is: " + driver.findElement(By.name("txtPwd")).getAttribute("value"));
		driver.findElement(By.className("Format")).sendKeys("kavi");
		Thread.sleep(2000);
		driver.findElement(By.id("txtUserName")).sendKeys("kavi");
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.alertIsPresent());
		String alrt = driver.switchTo().alert().getText();
		System.out.println(alrt);
		Thread.sleep(2000);
	}
	
	@Test
	public void testHeading()
	{
		String test=driver.findElement(By.xpath("html/body/h1")).getText();
		assertTrue(test.contains("Email"));
	}
	
	@AfterClass
	public static void closeBrowser()
	{
		driver.close();
		
	}
}
