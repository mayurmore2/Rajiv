import static org.junit.Assert.*;

import org.junit.*;
import org.junit.Test;


public class TestStudent {

	Student s1= new Student(101,"awed","Def");
	
	@Test
	public void getRollNo()
	{
		assertEquals(s1.getRollNo(),101);
		System.out.println("XYZ");
	}
	
	@Test
	public void getFirstName()
	{
		assertEquals(s1.getFirstname(),"awed");
	}	
	
	@Test
	public void xyz()
	{
		assertEquals(s1.getRollNo(),101);
		System.out.println("XYZ");
	}
	
	@Test
	public void abc()
	{
		//assertEquals(s1.getRollNo(),101);
		System.out.println("ABC");
	}
	
	@Before
	public void doBeforeTest()
	{
		System.out.println("One Time initialization before every test");
	}
	
	@After
	public void doAfterTest()
	{
		System.out.println("One Time initialization after every test");
	}
	
	@AfterClass
	public static void afterClass()
	{
		System.out.println("After class ");
	}
	
	@BeforeClass 
	public static void beforeClass()
	{
		System.out.println("Before class ");
	}
	
}
